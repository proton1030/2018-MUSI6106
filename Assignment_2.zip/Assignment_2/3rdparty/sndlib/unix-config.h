#ifndef UNIX_CONFIG_H
#define UNIX_CONFIG_H

#undef WORDS_BIGENDIAN
#undef SIZEOF_VOID_P
#undef HAVE_OSS
#undef HAVE_ALSA
#undef MUS_JACK
#undef MUS_PULSEAUDIO
#undef MUS_PORTAUDIO
#undef WITH_AUDIO

#undef HAVE_SCHEME
#undef HAVE_RUBY
#undef HAVE_FORTH

#undef HAVE_GSL

#endif
