#include "RequiredCheckException.h"

#ifndef UNITTEST_NO_EXCEPTIONS

namespace UnitTest {

   RequiredCheckException::RequiredCheckException()
   {
   }

   RequiredCheckException::~RequiredCheckException() throw()
   {
   }

}

#endif
