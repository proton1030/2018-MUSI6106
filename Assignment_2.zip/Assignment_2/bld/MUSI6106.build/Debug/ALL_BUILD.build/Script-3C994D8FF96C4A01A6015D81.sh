#!/bin/sh
make -C /Users/liuhanyu1030/Documents/audiosoftware/AudioSoftwareHW/Assignment_2/bld -f /Users/liuhanyu1030/Documents/audiosoftware/AudioSoftwareHW/Assignment_2/bld/CMakeScripts/ALL_BUILD_cmakeRulesBuildPhase.make$CONFIGURATION all
